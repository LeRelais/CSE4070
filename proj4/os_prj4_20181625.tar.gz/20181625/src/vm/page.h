#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <hash.h>
#include <list.h>
#include <threads/thread.h>
#include "filesys/off_t.h"


#endif
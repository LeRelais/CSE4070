#include <bitmap.h>
#include "vm/swap.h"
#include "vm/page.h"
#include "vm/frame.h"
#include "threads/vaddr.h"
#include "devices/block.h"
#include "userprog/syscall.h"

struct block *swap_block;
bool *swap_available;

void init_swap(){

}

int swap_out(void *vaddr, void *paddr){
  
}

void swap_in(void *vaddr, void *paddr, int swap_idx){
   
}
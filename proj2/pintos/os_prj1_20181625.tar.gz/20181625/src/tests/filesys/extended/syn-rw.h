#ifndef TESTS_FILESYS_EXTENDED_SYN_RW_H
#define TESTS_FILESYS_EXTENDED_SYN_RW_H

#define CHUNK_SIZE 8
#define CHUNK_CNT 512
#define BUF_SIZE (CHUNK_SIZE * CHUNK_CNT)
static const char file_name[] = "logfile";

#endif /* tests/filesys/extended/syn-rw.h */
